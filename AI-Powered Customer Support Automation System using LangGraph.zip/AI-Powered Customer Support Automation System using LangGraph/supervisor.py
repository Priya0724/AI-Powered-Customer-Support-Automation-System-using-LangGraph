def requires_approval(query):

    high_risk = [
        "refund",
        "cancel",
        "account closure",
        "compensation",
        "management"
    ]

    query = query.lower()

    for item in high_risk:
        if item in query:
            return True

    return False
print(
    requires_approval(
        "I need a refund"
    )
)
def supervisor_review(response):

    improved = (
        "ABC Technologies Support:\n\n"
        + response +
        "\n\nThank you for contacting us."
    )

    return improved
print(
    supervisor_review(
        "Refund request submitted."
    )
)