from typing import TypedDict

from langgraph.graph import StateGraph, START, END

from memory import get_last_issue
from supervisor import requires_approval, supervisor_review


# ==================================================
# STATE
# ==================================================

class SupportState(TypedDict):
    customer_name: str
    query: str
    intent: str
    retrieved_context: str
    approval_required: bool
    response: str


# ==================================================
# INTENT CLASSIFIER
# ==================================================

def classify_intent(state: SupportState):

    query = state["query"].lower()

    if "price" in query or "plan" in query:
        state["intent"] = "Sales"

    elif "password" in query or "account" in query:
        state["intent"] = "Account"

    elif "refund" in query or "invoice" in query:
        state["intent"] = "Billing"

    elif "previous" in query:
        state["intent"] = "Memory"

    else:
        state["intent"] = "Technical"

    print("Intent:", state["intent"])

    return state


# ==================================================
# ROUTER
# ==================================================

def route_intent(state: SupportState):
    return state["intent"]


# ==================================================
# SALES AGENT
# ==================================================

def sales_agent(state: SupportState):

    state["response"] = (
        "Our plans are Basic ($19/month), "
        "Professional ($49/month), "
        "and Enterprise."
    )

    return state


# ==================================================
# ACCOUNT AGENT
# ==================================================

def account_agent(state: SupportState):

    state["response"] = (
        "Please click 'Forgot Password' "
        "on the login page."
    )

    return state


# ==================================================
# TECHNICAL AGENT
# ==================================================

def technical_agent(state: SupportState):

    state["response"] = (
        "Please restart the application "
        "and check file compatibility."
    )

    return state


# ==================================================
# BILLING AGENT
# ==================================================

def billing_agent(state: SupportState):

    state["response"] = (
        "Your refund request has been submitted."
    )

    return state


# ==================================================
# MEMORY AGENT
# ==================================================

def memory_agent(state: SupportState):

    previous = get_last_issue(
        state["customer_name"]
    )

    state["response"] = (
        "Your previous issue was: "
        + previous
    )

    return state


# ==================================================
# RAG NODE
# ==================================================

def rag_node(state: SupportState):

    state["retrieved_context"] = (
        "Relevant information retrieved "
        "from company documents."
    )

    print(
        "RAG:",
        state["retrieved_context"]
    )

    return state


# ==================================================
# HUMAN APPROVAL
# ==================================================

def approval_node(state: SupportState):

    state["approval_required"] = (
        requires_approval(
            state["query"]
        )
    )

    if state["approval_required"]:
        print(
            "Human Approval Required"
        )

    return state


# ==================================================
# SUPERVISOR
# ==================================================

def supervisor_node(state: SupportState):

    state["response"] = (
        supervisor_review(
            state["response"]
        )
    )

    return state


# ==================================================
# LANGGRAPH
# ==================================================

builder = StateGraph(
    SupportState
)

# nodes
builder.add_node(
    "intent",
    classify_intent
)

builder.add_node(
    "sales",
    sales_agent
)

builder.add_node(
    "account",
    account_agent
)

builder.add_node(
    "technical",
    technical_agent
)

builder.add_node(
    "billing",
    billing_agent
)

builder.add_node(
    "memory",
    memory_agent
)

builder.add_node(
    "rag",
    rag_node
)

builder.add_node(
    "approval",
    approval_node
)

builder.add_node(
    "supervisor",
    supervisor_node
)

# START
builder.add_edge(
    START,
    "intent"
)

# conditional routing
builder.add_conditional_edges(
    "intent",
    route_intent,
    {
        "Sales": "sales",
        "Account": "account",
        "Billing": "billing",
        "Technical": "technical",
        "Memory": "memory"
    }
)

# agent → rag
builder.add_edge(
    "sales",
    "rag"
)

builder.add_edge(
    "account",
    "rag"
)

builder.add_edge(
    "technical",
    "rag"
)

builder.add_edge(
    "billing",
    "rag"
)

builder.add_edge(
    "memory",
    "rag"
)

# rag → approval
builder.add_edge(
    "rag",
    "approval"
)

# approval → supervisor
builder.add_edge(
    "approval",
    "supervisor"
)

# supervisor → end
builder.add_edge(
    "supervisor",
    END
)

# compile
graph = builder.compile()


# ==================================================
# RUN WORKFLOW
# ==================================================

def run_workflow(
        customer_name,
        query
):

    state = {
        "customer_name": customer_name,
        "query": query,
        "intent": "",
        "retrieved_context": "",
        "approval_required": False,
        "response": ""
    }

    result = graph.invoke(
        state
    )

    return result


# ==================================================
# OPTIONAL
# ==================================================

if __name__ == "__main__":

    print(
        graph.get_graph()
        .draw_ascii()
    )

