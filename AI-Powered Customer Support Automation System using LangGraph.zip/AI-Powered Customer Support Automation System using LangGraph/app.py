from workflow import run_workflow

queries = [

    (
        "David",
        "What are the pricing plans available for your software?"
    ),

    (
        "David",
        "I forgot my account password."
    ),

    (
        "David",
        "My application crashes whenever I upload a file."
    ),

    (
        "David",
        "I need a refund for my annual subscription."
    ),

    (
        "David",
        "What was my previous support issue?"
    )
]

for customer, query in queries:

    print("\n====================")

    print("QUERY:")
    print(query)

    result = run_workflow(
        customer,
        query
    )

    print("\nFINAL RESPONSE:")
    print(result["response"])

    print("====================")