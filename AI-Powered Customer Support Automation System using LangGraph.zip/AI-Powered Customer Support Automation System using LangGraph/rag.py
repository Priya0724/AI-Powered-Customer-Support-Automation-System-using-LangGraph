from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS

# Load all PDF files
files = [
    "documents/company_policy.pdf",
    "documents/pricing_guide.pdf",
    "documents/technical_manual.pdf",
    "documents/faq.pdf"
]

documents = []

for file in files:
    loader = PyPDFLoader(file)
    docs = loader.load()
    documents.extend(docs)

print("Documents loaded:", len(documents))

# Split into chunks
text_splitter = RecursiveCharacterTextSplitter(
    chunk_size=500,
    chunk_overlap=50
)

chunks = text_splitter.split_documents(documents)

print("Chunks created:", len(chunks))

# Create embeddings
embeddings = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2"
)

# Create vector database
vectorstore = FAISS.from_documents(
    chunks,
    embeddings
)

print("Vector database created successfully.")

# Test retrieval
query = "pricing plans"

results = vectorstore.similarity_search(query, k=2)

print("\nRetrieved Results:\n")

for i, result in enumerate(results):
    print("Result", i + 1)
    print(result.page_content)
    print("--------------------------------")