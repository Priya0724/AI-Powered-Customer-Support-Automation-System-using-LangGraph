# AI-Powered Customer Support Automation System using LangGraph

## Project Overview

This project implements an AI-Powered Customer Support Automation System for ABC Technologies using LangGraph. The system automates customer support operations by classifying customer queries, routing them to specialized support agents, retrieving relevant information from company documents using RAG (Retrieval-Augmented Generation), maintaining customer conversation history using SQLite memory, and handling human-in-the-loop approvals for critical requests.

The project demonstrates the use of LangGraph workflows, conditional routing, retrieval systems, memory management, and supervisor validation in an enterprise customer support environment.

---

## Business Problem

ABC Technologies receives thousands of customer support requests daily, including:

- Product information requests
- Technical issues
- Billing queries
- Account management requests
- Refund requests

Manual processing leads to:

- Increased response time
- Higher operational costs
- Inconsistent customer experience

This project automates the support process using AI agents and LangGraph workflows.

---

## Features

### 1. Intent Classification
The system classifies customer queries into:

- Sales
- Technical Support
- Billing
- Account Management
- Memory Recall

### 2. Conditional Routing
Queries are automatically routed to the appropriate support department using LangGraph conditional edges.

### 3. Specialized Support Agents

#### Sales Agent
Handles:
- Product information
- Pricing plans
- Subscription details

#### Technical Support Agent
Handles:
- Application crashes
- Login problems
- Installation issues
- Configuration errors

#### Billing Agent
Handles:
- Invoices
- Payments
- Refund requests

#### Account Agent
Handles:
- Password reset
- Profile updates
- Account activation/deactivation

### 4. Retrieval-Augmented Generation (RAG)
The system retrieves relevant information from company documents:

- Company Policy Document
- Pricing Guide
- Technical Manual
- FAQ Document

### 5. SQLite Memory
The system stores customer conversation history and retrieves previous interactions.

Example:

Customer:
```
My name is David. I have a billing issue.
```

Later:

```
What was my previous support issue?
```

Response:

```
Your previous issue was: I have a billing issue.
```

### 6. Human-in-the-Loop Approval
The following requests require human approval:

- Refund requests
- Subscription cancellation
- Account closure
- Compensation requests
- Escalation to management

### 7. Supervisor Agent
The supervisor validates and improves responses before they are sent to customers.

---

## Technologies Used

- Python
- LangGraph
- LangChain
- SQLite
- FAISS
- HuggingFace Embeddings
- PyPDFLoader
- Sentence Transformers

---

## Project Structure

```text
CustomerSupportAutomation/

├── app.py
├── workflow.py
├── state.py
├── memory.py
├── supervisor.py
├── rag.py

├── agents/
│   ├── sales.py
│   ├── technical.py
│   ├── billing.py
│   └── account.py

├── documents/
│   ├── company_policy.pdf
│   ├── pricing_guide.pdf
│   ├── technical_manual.pdf
│   └── faq.pdf

├── database/
│   └── memory.db

├── screenshots/

├── README.md
└── workflow_diagram.png
```

---

## LangGraph Workflow

The workflow follows this architecture:

```text
START
   |
Intent Classification
   |
Conditional Routing
   |
Sales / Technical / Billing / Account / Memory
   |
RAG Retrieval
   |
Human Approval
   |
Supervisor Agent
   |
SQLite Memory
   |
END
```

---

## Installation

Create a virtual environment:

```bash
python -m venv .venv
```

Activate virtual environment:

Windows:

```bash
.venv\Scripts\activate
```

Install dependencies:

```bash
pip install langgraph
pip install langchain
pip install langchain-community
pip install faiss-cpu
pip install sentence-transformers
pip install pypdf
pip install grandalf
```

---

## Running the Project

Run the application:

```bash
python app.py
```

Run workflow visualization:

```bash
python workflow.py
```

---

## Demonstration Queries

### Query 1

```
What are the pricing plans available for your software?
```

Expected Route:

```
Sales
```

---

### Query 2

```
I forgot my account password.
```

Expected Route:

```
Account
```

---

### Query 3

```
My application crashes whenever I upload a file.
```

Expected Route:

```
Technical Support
```

---

### Query 4

```
I need a refund for my annual subscription.
```

Expected Route:

```
Billing
→ Human Approval
```

---

### Query 5

```
What was my previous support issue?
```

Expected Route:

```
Memory Recall
```

---

## Assignment Tasks Completed

| Task | Description | Status |
|------|-------------|---------|
| Task 1 | LangGraph Workflow Design | Completed |
| Task 2 | State Structure | Completed |
| Task 3 | Intent Classification | Completed |
| Task 4 | Conditional Routing | Completed |
| Task 5 | Specialized Agents | Completed |
| Task 6 | RAG Integration | Completed |
| Task 7 | SQLite Memory | Completed |
| Task 8 | Human-in-the-Loop | Completed |
| Task 9 | Supervisor Agent | Completed |
| Task 10 | System Demonstration | Completed |

---

## Output Features Demonstrated

- Agent Routing
- LangGraph Conditional Workflow
- RAG Retrieval
- SQLite Memory Storage
- Memory Recall
- Human Approval
- Supervisor Validation
- Final Response Generation

---

## Author

Project: AI-Powered Customer Support Automation System using LangGraph

Institution: VIT Bhopal University

Course Project Submission